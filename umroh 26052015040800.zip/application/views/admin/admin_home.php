<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
</head>
<body>
		<?php echo anchor('admin_controller/show_data_agen', 'Data Agen'); ?>
		<?php echo anchor('admin_controller/logout', 'Logout'); ?>
</body>
</html>