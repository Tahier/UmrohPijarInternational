<!DOCTYPE html>
<html>
<head>
	<title>Portal Umrah</title>
</head>
<body>
	<ul>
		<li><?php echo anchor('admin_controller/', 'admin'); ?></li>
		<li><?php echo anchor('agen_controller/', 'agen'); ?></li>
	</ul>
</body>
</html>