<?php
	
	/**
	* 
	*/
	class agen_controller extends CI_Controller
	{

		private $limit = 10;
		
		function __construct()
		{
			parent::__construct();
			$this->load->model(array('paket_model', 'agen_model'));
			$this->load->library(array('form_validation', 'session'));
			$this->load->helper('url');
		}
		

		function index(){	
			$this->load->view('agen/agen_login');
		}

		function login(){
			$this->load->library('form_validation');

			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if($this->form_validation->run() == FALSE){
				$this->load->view('agen/agen_login');
			}
			else{

				$username = $this->input->post('username');
				$password = $this->input->post('password');

				$valid = $this->agen_model->login($username, $password);

					if($valid){
						redirect('agen_controller/agen_home', 'refresh');
						// echo "success";
						// $this->output->enable_profiler(TRUE);
						// print_r($valid);
					}
					else {
						redirect('agen_controller/login');
						// echo "failed";
						// $this->output->enable_profiler(TRUE);
						// print_r($valid);
						
					}
			}
		}

		function agen_home(){
				if($this->session->userdata('agen_logged_in')){
					$session_data = $this->session->userdata('agen_logged_in');
					$data['username'] = $session_data['agen_username'];
					$data['agen_id'] = $session_data['agen_id'];
					$this->load->view('agen/agen_home', $data);
				}
				else {
					redirect('agen_controller/login');
				}
			}

		function logout()
		{
			$this->session->unset_userdata('logged_in');
			session_destroy();
			redirect ('controller_index/', 'refresh');
		}



		function view_all_paket($offset = 0, $order_column = "paket_id", $order_type = "asc"){
			if(empty($order_column)){ $order_column = 'paket_id';}
			if(empty($order_type)){$order_type = 'asc';}
			if(empty($offset)){ $offset = 0; }


			$session_data = $this->session->userdata('agen_logged_in');

			$this->db->where('agen_id',$session_data['agen_id'] );
			$pakets = $this->paket_model->paket_get_paged_list($this->limit, $offset, $order_column, $order_type)->result();

			//pagination
			$this->load->library('pagination');
			
			$config['base_url'] = site_url('agen_controller/view_all_paket');
			$config['total_rows'] = $this->paket_model->paket_count_all();
			$config['per_page'] = $this->limit;
			$config['uri_segment'] = 3;
			
			$this->pagination->initialize($config);
			
			$data['pagination'] = $this->pagination->create_links();

			//table

			$this->load->library('table');
			$this->table->set_empty("&nbsp");
			$new_order = ($order_type=='asc'?'desc':'asc');
			
			$this->table->set_heading('No',
									   anchor('agen_controller/view_all_paket/'.$offset.'/paket_nomor/'.$new_order, 'Nomor Paket'),
									   anchor('agen_controller/view_all_paket/'.$offset.'/paket_nama/'.$new_order, 'Nama Paket'),
									   anchor('agen_controller/view_all_paket/'.$offset.'/paket_harga/'.$new_order, 'Harga Paket'),
									   'Aksi');

			$i = 0+$offset;

			foreach ($pakets as $paket) {
				$this->table->add_row(++$i,
									   $paket->paket_nomor,
									   $paket->paket_nama,
									   $paket->paket_harga,
									   anchor('agen_controller/detail_paket/'.$paket->paket_nomor, 'Detail')."  ".
									   anchor('agen_controller/edit_paket/'.$paket->paket_nomor, 'Edit')."   ".
									   anchor('agen_controller/delete_paket/'.$paket->paket_nomor, 'delete', array('onclick' => "return confirm('apakah anda yakin ingin menghapus data agen ".$paket->paket_nama ."?')"))
									   );
			}
			
			$data['table']=$this->table->generate();

			$this->load->view('agen/agen_data_paket', $data);
		}


		function add_paket(){

			$this->_set_rules();

			if($this->form_validation->run() == FALSE){

				$random = rand(00,99);
				$data['nomor'] = date('himsy').$random;
				$this->load->view('agen/agen_add_paket', $data);
			}
			else {
				$this->paket_model->add_paket();
				redirect('agen_controller/view_all_paket', 'refresh');
			}
		}



		public function get_primary($id){     
			$primary = $this->paket_model->nomor_to_primary($id)->row();    
			return $primary_id = $primary->paket_id;

		}


		function detail_paket($id){
			
			$data['paket'] = $this->paket_model->paket_get_by_id($this->get_primary($id))->row_array();
			$data['paket']['paket_tgl_berangkat'] = date("d M Y, H:i:s", strtotime($data['paket']['paket_tgl_berangkat']));
			$data['paket']['paket_tgl_pulang'] = date("d M Y, H:i:s", strtotime($data['paket']['paket_tgl_pulang']));
			$data['paket']['paket_created'] = date("d M Y, H:i:s", strtotime($data['paket']['paket_created']));

			$this->load->view('agen/agen_detail_paket', $data, FALSE);

		}


		function edit_paket($id){

			$this->_set_rules();

			if($this->form_validation->run() == FALSE){

			$data['paket'] = $this->paket_model->paket_get_by_id($this->get_primary($id))->row_array();

			$this->load->view('agen/agen_edit_paket', $data);
			}
			else
			{
				$this->paket_model->update_paket($this->get_primary($id));
				redirect('agen_controller/view_all_paket');
			}
		}

		function delete_paket($id){
			$this->paket_model->delete_paket($this->get_primary($id));
			redirect('agen_controller/view_all_paket', 'refresh');
		}

		function _set_rules(){
			$this->form_validation->set_rules('paket_nama', 'Nama Agen', 'required');
			$this->form_validation->set_rules('paket_deskripsi', 'Deskripsi Paket','required');
			$this->form_validation->set_rules('paket_harga', 'Harga Paket', 'required');
		}


	}