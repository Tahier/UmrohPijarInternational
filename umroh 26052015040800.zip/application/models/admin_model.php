<?php
	
	/**
	* 
	*/
	class admin_model extends CI_Model
	{
		private $tablename = 'admin';
		private $primarykey = 'admin_id';


		function __construct()
		{
			# code...
			parent::__construct();

		}

		function admin_login($username, $password){
			//panggil dari database
			$this->db->where('admin_username', $username);
			$this->db->where('admin_password', $password);
			$result = $this->db->get($this->tablename);


			//jika data ada
			if($result->num_rows() > 0){
				//mengubah data yang didapat menjadi array
				$row = $result->row_array();
				//set variabel session
				$data = array(
							'admin_id' => $row['admin_id'],
							'admin_username' => $row['admin_username'],
							'admin_password' => $row['admin_password'] );

				$this->session->set_userdata('admin_logged_in', $data);
				return TRUE;
			}
			else {
				return FALSE;
			}
		}

		
	}